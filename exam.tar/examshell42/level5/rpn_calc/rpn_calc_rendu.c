/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rpn_calc_rendu.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/03/07 13:23:27 by tpacaly           #+#    #+#             */
/*   Updated: 2018/03/07 13:23:29 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include <stdlib.h>
# include <stdio.h>
# include <unistd.h>

typedef	struct		s_list
{
	int				val;
	struct s_list	*next;
}					t_list;

int	ft_isnum(char *str)
{
	int i = 0;

	if (str[i] == '-' || str[i] == '+')
		++i;
	if ('0' <= str[i] && str[i] <= '9')
		return (1);
	return (0);
}

int	ft_isop(char c)
{
	if (c == '+' || c == '-' || c == '*' || c == '/' || c == '%')
		return (1);
	return (0);
}

void	ft_lstadd(t_list **begin_list, int val)
{
	t_list	*new;

	if ((new = (t_list *)malloc(sizeof(t_list))))
	{
		new->val = val;
		new->next = *begin_list;
		*begin_list = new;
	}
}

void	ft_lstdel(t_list **begin_list)
{
	t_list	*tmp;

	tmp = *begin_list;
	*begin_list = tmp->next;
	free(tmp);
}

int	ft_operate(t_list **begin_list, char c)
{
	t_list	*scout;
	int		*a;
	int 	b;

	if (!*begin_list || !(scout = (*begin_list)->next))
		return (0);
	a = &scout->val;
	b = (*begin_list)->val;
	if (c == '+')
		*a += b;
	else if (c == '-')
		*a -= b;
	else if (c == '*')
		*a *= b;
	else if (c == '/')
	{
		if (b == 0)
			return (0);
		*a /= b;
	}
	else if (c == '%')
	{
		if (b == 0)
			return (0);
		*a %= b;
	}
	ft_lstdel(begin_list);
	return (1);
}

char	*advance(char *str)
{
	while (*str && *str != ' ')
		++str;
	return (str);
}

int main(int ac, char **av)
{
	if (ac == 2)
	{
		char	*str = av[1];
		t_list	*begin_list = NULL;

		while (*str)
		{
			if (ft_isnum(str))
			{
				ft_lstadd(&begin_list, atoi(str));
				str = advance(str);
			}
			else if (ft_isop(*str))
			{
				if (!ft_operate(&begin_list, *str))
					break ;
				str = advance(str);
			}
			else if (*str == ' ')
			{
				if (!*(str + 1))
					break;
				++str;
			}
			else
				break ;
		}
		if (*str || begin_list->next)
			write(1, "Error\n", 6);
		else
			printf("%d\n", begin_list->val);
		while (begin_list)
			ft_lstdel(&begin_list);
	}
	else
		write(1, "Error\n", 6);
	return (0);
}
