/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   brackets_rendu.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/03/07 12:17:34 by tpacaly           #+#    #+#             */
/*   Updated: 2018/03/07 12:17:54 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		brack(char *str)
{
	int hg[100];
	int cmpt = 0;
	int g = 0;
	while(str[g])
	{
		if(str[g] == '{')
		{
			hg[cmpt] = 1;
			cmpt++;
		}
		if(str[g] == '(')
		{   
			hg[cmpt] = 2;
			cmpt++;
		} 
		if(str[g] == '[')
		{   
			hg[cmpt] = 3;
			cmpt++;
		} 
		if(str[g] == ']')
		{
			if(hg[cmpt-1] == 3)
				cmpt--;
			else
				return(0);
		}
		if(str[g] == '}')
		{
			if(hg[cmpt-1] == 1)
				cmpt--;
			else
				return(0);
		}
		if(str[g] == ')')
		{
			if(hg[cmpt-1] == 2)
				cmpt--;
			else
				return(0);
		}
		g++;
	}
	if(cmpt == 0)
		return(1);
	return(0);
}

int main(int c, char **v)
{
	int h = 1;
	int h0 = 0;
	if(c == 1)
	{
		write(1, "\n", 1);
		return(0);
	}
	while(c > h)
	{	
		h0 = brack(v[h]);
		if(h0 == 0)
			write(1, "Error\n", 6);
		else
			write(1, "OK\n", 3);
		h++;
	}
}

