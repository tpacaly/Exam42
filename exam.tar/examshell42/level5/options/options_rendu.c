/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   options_rendu.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/03/07 13:11:52 by tpacaly           #+#    #+#             */
/*   Updated: 2018/03/07 13:11:53 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void affiche_binaire(int i)
{
	write(1, "000000", 6);
	((i & (1 << 25)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 24)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	write(1, " ", 1);
	((i & (1 << 23)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 22)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 21)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 20)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 19)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 18)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 17)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 16)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	write(1, " ", 1);
	((i & (1 << 15)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 14)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 13)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 12)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 11)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 10)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 9)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 8)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	write(1, " ", 1);
	((i & (1 << 7)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 6)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 5)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 4)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 3)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 2)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & (1 << 1)) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	((i & 1) > 0) ? write(1, "1", 1) : write(1, "0", 1);
	write(1, "\n", 1);
}

int verifie(char *str)
{
	int g = 1;
	if(str[0] != '-')
		return(2);
	while(str[g] && str[g] > 0x60 && str[g] < 0x7b)
		g++;
	if(str[g])
		return(0);
	return(1);
}

int recupere(char *str)
{
	int g = 1;
	int aide = 0;
	char c;
	int ret = 0;
	while(str[g])
	{
		c = str[g];
		aide = c - 0x61;
		ret |= 1 << aide;
		g++;
	}
	return(ret);
}

int ft_error(void)
{
	write(1, "Invalid Option\n", 15);
	return(0);
}

int main(int c, char **v)
{
	int options = 0;
	int arg = 1;
	int help = 0;
	if(c == 1)
	{
		write(1, "options: abcdefghijklmnopqrstuvwxyz\n", 36);
		return(0);
	}
	while(c > arg)
	{
		help = verifie(v[arg]);
		if(help == 0)
			return(ft_error());
		if(help == 1)
			options |= recupere(v[arg]);
		arg++;
	}
	((options & 128) == 128) ? write(1, "options: abcdefghijklmnopqrstuvwxyz\n", 36) : affiche_binaire(options);
	return(0);
}

