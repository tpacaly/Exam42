/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   moment_rendu.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/03/07 13:38:12 by tpacaly           #+#    #+#             */
/*   Updated: 2018/03/25 17:11:12 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		nbr_octet(int	nbr)
{
	int		i;

	i = 1;
	while ((nbr = nbr / 10))
		i++;
	return (i);
}

char	*ft_itoa(int nbr)
{
	char	*ret;
	int		neg;
	int		len;
	int		i;
	int		exept;

	neg = (nbr >= 0) ? 0 : 1;
	exept = (nbr == -2147483648) ? 1 : 0;
	if (exept)
		nbr = 2147483647;
	nbr = (nbr > 0) ? nbr : -nbr;
	len = nbr_octet(nbr) + neg;
	ret = (char *)malloc(sizeof(char) * (len + 1));
	ret[len] = '\0';
	ret[len - 1] = '0' + nbr % 10;
	i = len - 2;
	while ((nbr = nbr / 10))
	{
		ret[i] = '0' + nbr % 10;
		i--;
	}
	if (exept)
		ret[len - 1] = '0' + 8;
	if (neg)
		ret[0] = '-';
	return (ret);
}

char	*ft_strdup(const char *s1)
{
	char	*chaine;
	int		taille;
	int		i;

	i = 0;
	taille = 0;
	while (s1[taille])
		taille++;
	if ((chaine = (char*)malloc(sizeof(*chaine) * (taille + 1))) == NULL)
		return (NULL);
	while (i < taille)
	{
		chaine[i] = s1[i];
		i++;
	}
	chaine[taille] = '\0';
	return (chaine);
}

char	*ft_strcat(char *s1, const char *s2)
{
	int i;
	int s;

	i = 0;
	s = 0;
	if (s2[0] == '\0')
		return (s1);
	while (s1[i])
		i++;
	while (s2[s])
		s1[i++] = s2[s++];
	s1[i] = '\0';
	return (s1);
}

char	*ft_strcpy(char *dst, const char *src)
{
	unsigned int i;

	i = 0;
	while (src[i])
	{
		dst[i] = src[i];
		i++;
	}
	dst[i] = '\0';
	return (dst);
}

void	ft_bzero(void *s, size_t n)
{
	unsigned char	*c;
	int				d;

	c = (unsigned char *)s;
	d = 0;
	while (n != 0)
	{
		c[d] = '\0';
		n--;
		d++;
	}
}

int ft_strlen(const char *v)
{
	int i;

	i = 0;
	while(v[i])
		i++;
	return(i);
}

char	*ft_strjoin(char const *s1, char const *s2)
{
	size_t	taille;
	char	*chaine;

	if (!s1 || !s2)
		return (NULL);
	taille = ft_strlen(s1) + ft_strlen(s2);
	chaine = (char *)malloc(sizeof(*chaine) * (taille + 1));
	ft_bzero(chaine, taille + 1);
	if (chaine == NULL)
		return (NULL);
	ft_strcpy(chaine, s1);
	ft_strcat(chaine, s2);
	return (chaine);
}

char	*months(unsigned int duration)
{
	char *res;

	duration /= 2592000;
	res = ft_strjoin(ft_itoa(duration), " months ago.");
	return(res);
}

char	*days(unsigned int duration)
{
	char *res;

	duration /= 86400;
	res = ft_strjoin(ft_itoa(duration), " days ago.");
	return(res);
}

char	*hours(unsigned int duration)
{
	char *res;

	duration /= 3600;
	res = ft_strjoin(ft_itoa(duration), " hours ago.");
	return(res);
}

char	*minutes(unsigned int duration)
{
	char *res;

	duration /= 60;
	res = ft_strjoin(ft_itoa(duration), " minutes ago.");
	return(res);
}

char	*seconds(unsigned int duration)
{
	char *res;

	res = ft_strjoin(ft_itoa(duration), " seconds ago.");
	return(res);
}

char    *moment(unsigned int duration)
{
	char *ret;

	if(duration >= 60)
	{
		if(duration >= 3600)
		{
			if(duration >= 86400)
			{
				if(duration >= 2592000)
					return((duration >= 2592000 && duration < 5184000) ? ft_strdup("1 month ago.") : months(duration));
				else
					return((duration >= 86400 && duration < 172800) ? ft_strdup("1 day ago.") : days(duration));
			}
			else
				return((duration >= 3600 && duration < 7200) ? ft_strdup("1 hour ago.") : hours(duration));
		}
		else
			return((duration >= 60 && duration < 120) ? ft_strdup("1 minute ago.") : minutes(duration));
	}
	else
	{
		if(duration < 2)
		{
			ret = (duration == 0) ? ft_strdup("0 second ago.") : ft_strdup("1 second ago.");
			return(ret);
		}
		else
			return(seconds(duration));
	}
}

