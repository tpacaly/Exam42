/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   moment_rendu.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/03/07 13:38:12 by tpacaly           #+#    #+#             */
/*   Updated: 2018/03/20 09:16:02 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int		nbr_octet(int	nbr)
{
	int		i;

	i = 1;
	while ((nbr = nbr / 10))
		i++;
	return (i);
}

char	*ft_itoa(int nbr)
{
	char	*ret;
	int		neg;
	int		len;
	int		i;
	int		exept;

	neg = (nbr >= 0) ? 0 : 1;
	exept = (nbr == -2147483648) ? 1 : 0;
	if (exept)
		nbr = 2147483647;
	nbr = (nbr > 0) ? nbr : -nbr;
	len = nbr_octet(nbr) + neg;
	ret = (char *)malloc(sizeof(char) * (len + 1));
	ret[len] = '\0';
	ret[len - 1] = '0' + nbr % 10;
	i = len - 2;
	while ((nbr = nbr / 10))
	{
		ret[i] = '0' + nbr % 10;
		i--;
	}
	if (exept)
		ret[len - 1] = '0' + 8;
	if (neg)
		ret[0] = '-';
	return (ret);
}

char	*ft_strdup(const char *s1)
{
	char	*chaine;
	int		taille;
	int		i;

	i = 0;
	taille = 0;
	while (s1[taille])
		taille++;
	if ((chaine = (char*)malloc(sizeof(*chaine) * (taille + 1))) == NULL)
		return (NULL);
	while (i < taille)
	{
		chaine[i] = s1[i];
		i++;
	}
	chaine[taille] = '\0';
	return (chaine);
}

char	*years(unsigned int duration)
{
	char *s;
	char c;

	duration /= 25920000;
	if (duration < 9)
	{
		c = duration + '0';
		s = ft_strdup("  years ago.");
		s[0] = c;
	}
	if (duration > 99)
	{
		c = (duration % 10) + '0';
		s = ft_strdup("    years ago.");
		s[2] = c;
		duration /= 10;
		c = (duration % 10) + '0';
		s[1] = c;
		c = (duration / 10) + '0';
		s[0] = c;
	}
	else
	{
		c = (duration % 10) + '0';
		s = ft_strdup("   years ago.");
		s[1] = c;
		c = (duration / 10) + '0';
		s[0] = c;
	}
	return(s);
}

char	*weeks(unsigned int duration)
{
	char *s;
	char c;

	duration /= 604800;
	if(duration > 9)
	{
		c = (duration % 10) + '0';
		s = ft_strdup("   weeks ago.");
		s[1] = c;
		c = (duration / 10) + '0';
		s[0] = c;
	}
	else
	{
		c = duration + '0';
		s = ft_strdup("  weeks ago.");
		s[0] = c;
	}
	return(s);
}

char	*days(unsigned int duration)
{
	char *s;
	char c;

	duration /= 86400;
	if(duration > 9)
	{
		c = (duration % 10) + '0';
		s = ft_strdup("   days ago.");
		s[1] = c;
		c = (duration / 10) + '0';
		s[0] = c;
	}
	else
	{
		c = duration + '0';
		s = ft_strdup("  days ago.");
		s[0] = c;
	}
	return(s);
}

char	*hours(unsigned int duration)
{
	char *s;
	char c;

	duration /= 3600;
	if(duration > 9)
	{
		c = (duration % 10) + '0';
		s = ft_strdup("   hours ago.");
		s[1] = c;
		c = (duration / 10) + '0';
		s[0] = c;
	}
	else
	{
		c = duration + '0';
		s = ft_strdup("  hours ago.");
		s[0] = c;
	}
	return(s);
}

char	*minutes(unsigned int duration)
{
	char *s;
	char c;

	duration /= 60;
	if(duration > 9)
	{
		c = (duration % 10) + '0';
		s = ft_strdup("   minutes ago.");
		s[1] = c;
		c = (duration / 10) + '0';
		s[0] = c;
	}
	else
	{
		c = duration + '0';
		s = ft_strdup("  minutes ago.");
		s[0] = c;
	}
	return(s);
}

char	*seconds(unsigned int duration)
{
	char *s;
	char c;

	if(duration > 9)
	{
		c = (duration % 10) + '0';
		s = ft_strdup("   seconds ago.");
		s[1] = c;
		c = (duration / 10) + '0';
		s[0] = c;
	}
	else
	{
		c = duration + '0';
		s = ft_strdup("  seconds ago.");
		s[0] = c;
	}
	return(s);
}

char    *moment(unsigned int duration)
{
	if(duration >= 60)
	{
		if(duration >= 3600)
		{
			if(duration >= 86400)
			{
				if(duration >= 604800)
				{
					if(duration >= 25920000)
					{
						return((duration >= 25920000 && duration < 51840000) ? ft_strdup("1 year ago.") : years(duration));
					}
					else
						return((duration >= 604800 && duration < 1209600) ? ft_strdup("1 week ago.") : weeks(duration));
				}
				else
					return((duration >= 86400 && duration < 172800) ? ft_strdup("1 day ago.") : days(duration));
			}
			else
				return((duration >= 3600 && duration < 7200) ? ft_strdup("1 hour ago.") : hours(duration));
		}
		else
			return((duration >= 60 && duration < 120) ? ft_strdup("1 minute ago.") : minutes(duration));
	}
	else
		return((duration == 1) ? ft_strdup("1 second ago.") : seconds(duration));
}

int main(int c, char **v)
{
	unsigned int x = 0;
	int y = 0;
	char *s;

	if(c != 2)
		return(0);
	y = atoi(v[1]);
	x = y;
	s = moment(x);
	printf("%s\n", s);
	free(s);
	return(0);
}
