/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   moment_rendu.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/03/07 13:38:12 by tpacaly           #+#    #+#             */
/*   Updated: 2018/03/07 13:52:26 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
(to be continued.)


char *ft_strdup(char *s)


char    *moment(unsigned int duration)
{
	if(duration >= 60)
	{
		if(duration >= 3600)
		{
			if(duration >= 86400)
			{
				if(duration > 604800)
				{
					if(duration > 25920000)
						return(months(duration));
					else
						return(weeks(duration));
				}
				else
					return(days(duration));
			}
			else
				return(hours(duration))
		}
		else
			return(minutes(duration))
	}
	else
		return(seconds(duration));
}
