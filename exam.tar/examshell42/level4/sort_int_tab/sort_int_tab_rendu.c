/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_int_tab_rendu.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/03/07 13:58:09 by tpacaly           #+#    #+#             */
/*   Updated: 2018/03/07 13:58:14 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void sort_int_tab(int *tab, unsigned int size)
{
	unsigned int x = 0;
	int help = 0;
	while(x + 1 != size)
	{
		if(tab[x] > tab[x+1])
		{
			help = tab[x+1];
			tab[x+1] = tab[x];
			tab[x] = help;
			x = 0;
		}
		else
			x++;
	}
}

